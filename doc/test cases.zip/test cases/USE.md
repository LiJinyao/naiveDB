### USE
#### 语法定义：
```
USE database_name
)
```
##### Case 1
创建表测试。

input:
```
USE mydatabase
```
expect:
```
切换到名为mydatabase的数据库
```
